import { execLadder } from "./ladder.js";

export class VirtualPLC {
  constructor({ io, scanMs = 50, features = { python: false } }) {
    this.io = io;
    this.scanMs = scanMs;
    this.features = features;

    this.programIR = { language: "ladder", networks: [] };

    this.running = false;
    this._interval = null;
    this._inScan = false;

    this.lastError = null;
    this.lastDiag = { pyErrors: [] };

    // Strict PLC mode: restrict dynamic behavior (e.g., dynamic IO growth).
    this.strict = false;

    // Scan timing stats (execution time, not configured interval)
    this.scanStats = {
      intervalMs: this.scanMs,
      lastMs: 0,
      avgMs: 0,
      p95Ms: 0,
      maxMs: 0,
      overruns: 0,
      samples: 0
    };
    this._scanHist = []; // ring buffer of recent scan durations
    this._scanHistMax = 240;
  }

  setProgramIR(ir) {
    this.programIR = ir;
  }

  setStrict(on) {
    this.strict = !!on;
    if (this.io?.setStrict) this.io.setStrict(this.strict);
  }

  start() {
    if (this.running) return;
    this.running = true;
    this._interval = setInterval(() => { this.scan(); }, this.scanMs);
  }

  stop() {
    this.running = false;
    if (this._interval) clearInterval(this._interval);
    this._interval = null;
  }

  powerCycle({ retainMem = true, clearFaults = false } = {}) {
    // Simulate a PLC power cycle:
    // - outputs drop
    // - timers reset
    // - memory optionally retentive
    // - faults/forces optionally cleared
    const wasRunning = this.running;
    this.stop();
    if (this.io?.reset) this.io.reset({ retainMem, clearFaults });
    this.lastError = null;
    this.lastDiag = { pyErrors: [] };
    if (wasRunning) this.start();
  }

  async scan() {
    if (this._inScan) return;
    this._inScan = true;

    const t0 = process.hrtime.bigint();
    let tInputMs = 0;
    let tLogicMs = 0;
    let tHouseMs = 0;

    const tInput0 = process.hrtime.bigint();
    const I = this.io.inputImage();         // input image snapshot (with faults applied)
    const Q = this.io.bankProxy("Q");       // outputs with fault-aware reads + write blocking
    const M = this.io.bankProxy("M");       // memory with fault-aware reads + write blocking
    const A = { ...(this.io.analogInputs || {}) };  // analog input image (read-only for logic)
    const B = this.io.analogOutputs || {};          // analog outputs (numeric, writable by logic if we add MOV)
    const tInput1 = process.hrtime.bigint();
    tInputMs = Number(tInput1 - tInput0) / 1e6;

    const pyCache = new Map();
    const DIAG = { pyErrors: [] };

    const ctx = {
      I, Q, M, A, B, DIAG,
      FEATURES: this.features,
      TON: (name, presetMs, enable) => {
        const t = this.io.ensureTimer(name, presetMs);
        const now = Date.now();
        if (!enable) {
          t.startMs = null;
          t.done = false;
          t.elapsedMs = 0;
          return { done: t.done, elapsedMs: t.elapsedMs };
        }
        if (t.startMs === null) t.startMs = now;
        t.elapsedMs = now - t.startMs;
        t.done = t.elapsedMs >= t.presetMs;
        return { done: t.done, elapsedMs: t.elapsedMs };
      }
    };

    try {
      if (this.programIR.language === "ladder") {
        const tLogic0 = process.hrtime.bigint();
        await execLadder(this.programIR, ctx, pyCache);
        const tLogic1 = process.hrtime.bigint();
        tLogicMs = Number(tLogic1 - tLogic0) / 1e6;
      } else {
        // ST interpreter not included in this demo build; export ST is supported.
        throw new Error(`Unsupported language '${this.programIR.language}' in runtime (demo build).`);
      }
      this.lastError = null;
      this.lastDiag = DIAG;
    } catch (e) {
      this.lastError = String(e?.stack || e);
      this.lastDiag = DIAG;
    } finally {
      // Update scan stats
      const tHouse0 = process.hrtime.bigint();
      const t1 = process.hrtime.bigint();
      const durMs = Number(t1 - t0) / 1e6;

      this.scanStats.intervalMs = this.scanMs;
      this.scanStats.lastMs = durMs;
      this.scanStats.samples++;
      const n = this.scanStats.samples;
      // Running average
      this.scanStats.avgMs = n === 1 ? durMs : (this.scanStats.avgMs + (durMs - this.scanStats.avgMs) / n);
      this.scanStats.maxMs = Math.max(this.scanStats.maxMs || 0, durMs);
      if (durMs > this.scanMs) this.scanStats.overruns++;

      this._scanHist.push(durMs);
      if (this._scanHist.length > this._scanHistMax) this._scanHist.shift();
      // p95 from recent history (cheap; N <= 240)
      const sorted = [...this._scanHist].sort((a, b) => a - b);
      const idx = Math.max(0, Math.min(sorted.length - 1, Math.ceil(sorted.length * 0.95) - 1));
      this.scanStats.p95Ms = sorted.length ? sorted[idx] : 0;

      // Phase timings (last + running avg)
      if (!this.scanStats.phases) {
        this.scanStats.phases = {
          last: { inputMs: 0, logicMs: 0, housekeepingMs: 0 },
          avg: { inputMs: 0, logicMs: 0, housekeepingMs: 0 }
        };
      }
      // housekeeping = stats + any post-scan work
      const tHouse1 = process.hrtime.bigint();
      tHouseMs = Number(tHouse1 - tHouse0) / 1e6;
      this.scanStats.phases.last = { inputMs: tInputMs, logicMs: tLogicMs, housekeepingMs: tHouseMs };
      const n2 = this.scanStats.samples || 1;
      const a = this.scanStats.phases.avg;
      a.inputMs = n2 === 1 ? tInputMs : (a.inputMs + (tInputMs - a.inputMs) / n2);
      a.logicMs = n2 === 1 ? tLogicMs : (a.logicMs + (tLogicMs - a.logicMs) / n2);
      a.housekeepingMs = n2 === 1 ? tHouseMs : (a.housekeepingMs + (tHouseMs - a.housekeepingMs) / n2);

      this._inScan = false;
    }
  }
}
