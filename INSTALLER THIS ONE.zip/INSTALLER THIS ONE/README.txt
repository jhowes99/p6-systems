Ironclad Runtime — Docker installer
====================================

Quick start:
  1. Extract this zip to a folder (e.g. Desktop).
  2. Double-click Run-Ironclad-Runtime.bat
  3. First time only: if Docker is not installed, right-click the bat file
     and choose "Run as administrator" so Docker Desktop can be installed.
  4. When the app is running, open http://localhost:3000 in your browser.
  5. To stop: double-click Stop-Ironclad-Runtime.bat

Optional: to allow one-click Docker install for users who don't have Docker,
  put "Docker Desktop Installer.exe" in the installer\docker\ folder
  (see installer\docker\README.txt).

This package contains the axiom_runtime Docker setup only (no proxy/HMI).
All app code is built inside the container; no Node.js or Python needed on the host.
